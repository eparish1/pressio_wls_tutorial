
Some parts of this mpl directory have been adapted/extended/forked 
from the tinympl project, forked from http://sbabbi.github.io/tinympl.  
The tinympl project appears to be no longer maintained. 
The original files contained the following header:

```cpp
// Copyright (C) 2013, Ennio Barbaro.
//
// Use, modification, and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://sbabbi.github.io/tinympl for documentation.
//
// You are welcome to contact the author at:
//  enniobarbaro@gmail.com
//
```

The above copyright is incorporated into all headers inside Pressio/mpl 
that have been used from tinympl. 

All of this is legal under the terms of the original tinympl license, 
which is included in  `tinympl.txt` under pressio/licences-tpls.

